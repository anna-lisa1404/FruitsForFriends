<?php
/*
* bearbeitet von: Anna-Lisa Merkel
*/

define('IMAGEPATH', 'assets'.DIRECTORY_SEPARATOR.'images'.DIRECTORY_SEPARATOR);
define('PAGESPATH', 'views'.DIRECTORY_SEPARATOR.'pages'.DIRECTORY_SEPARATOR);
define('SHOPPATH', 'views'.DIRECTORY_SEPARATOR.'shop'.DIRECTORY_SEPARATOR);
define('CONTROLLERSPATH',  'controllers'.DIRECTORY_SEPARATOR);
define('COREPATH',  'core'.DIRECTORY_SEPARATOR);
define('MODELSPATH', 'models'.DIRECTORY_SEPARATOR);
define('VIEWSPATH', 'views'.DIRECTORY_SEPARATOR);