<!-- bearbeitet von: Anna-Lisa Merkel -->

<div class="products-nav">  
    <nav>
        <a href="index.php?c=shop&a=allproducts">Alle Getränke</a>
        <a href="index.php?c=shop&a=juices">Säfte</a>
        <a href="index.php?c=shop&a=smoothies">Smoothies</a>
    </nav>
</div>