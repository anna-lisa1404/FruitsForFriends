<!-- bearbeitet von: Anna-Lisa Merkel -->

<div class="background-picture-products">    
    <?php include(SHOPPATH.'shopNav.php'); ?>
    
    <div class="product-introduction">
        <h3>Hier gibt's leckere Getränke!</h3>
        <p>Wähle oben aus, ob du lieber Säfte, Smoothies oder alle Getränke durchsuchen möchtest.</p>
    </div>
</div>