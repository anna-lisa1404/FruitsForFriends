<!-- bearbeitet von: Anna-Lisa Merkel -->

<div class="background-picture-order">
    <div class="order-notification">
        <h1>Vielen Dank für deine Bestellung!</h1>
        <br>
        <p>In 3 - 4 Werktagen wird sie unser Lager verlassen und sich auf den Weg zu dir machen.</p>
        <br>
        <a href="index.php?c=pages&a=startpage">Zurück zur Startseite!</a>
    </div>
</div>