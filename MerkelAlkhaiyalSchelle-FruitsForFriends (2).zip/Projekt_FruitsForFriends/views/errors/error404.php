<!-- bearbeitet von: Anna-Lisa Merkel -->

<div class="background-picture-error">
    <div class="error-wrapper">
        <div class="form-area">
            <h1>Error404</h1>
            <div class="error-description">
                <p>Da läuft was schief...</p>
                <p>Sorry, aber die Seite, die du suchst, scheint weggelaufen zu sein.</p>
            </div>

            <div class="form-link">
                <br>
                <a href="index.php?c=pages&a=startpage">Bring mich zurück zur Startseite!</a>
            </div>
        </div>
    </div>
</div>