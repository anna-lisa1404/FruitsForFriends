<!-- bearbeitet von: Sarah Schelle -->

<div class="scontainer">
    <h1>Startseite</h1>

    <div class="start" action="index.php?c=pages&a=startpage" id="startpage">
        <div class="startcard1">
            <img src=<?= IMAGEPATH.'decoration_pics/womansmoothie.jpg' ?> alt="Frau mit Smoothie" style="width:100%" /> 
            <p>Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
            </p>   
        </div>
        <div class="startcard2">
            <img src=<?= IMAGEPATH.'decoration_pics/stock_green_guy.jpg' ?> alt="Mann mit grünem Smoothie" width="100%" />
            <p>Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
                Lorem ipsum dolor sit amet, consetetur
                sadipscing elitr, sed diam nonumy eirmod
                tempor my eirmod tempor invidunt ut labore et
                dolore magna aliquyam erat.
            </p>
        </div>
</div>