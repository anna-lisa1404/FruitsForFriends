<!-- bearbeitet von: Salma Alkhaiyal -->

    <h1>Blog</h1>
    
        <div class="column" action="index.php?c=pages&a=blog" method="post">
            <div class="card">
                <h2>TITLE HEADING</h2>
                <h5>Title description, Dec 7, 2020</h5>
                <img src=<?= IMAGEPATH.'decoration_pics/fruits1.jpg' ?> alt="blog"> 
                    <p>unsere gute Produkte..</p>
                    <p>
                        wir sind sehr bemüht und sorgfältig, damit wir immer das beste Obst und 
                        Gemüse für unsere Produkte zu ermöglichen.
                    </p>
                
            </div>
            <div class="card">
                <h2>TITLE HEADING</h2>
                <h5>Title description, Jan 5, 2021</h5>
                <img src=<?= IMAGEPATH.'decoration_pics/Baum.jpeg' ?> alt="blog">
                <p>ein Baum pflanzen..</p>
                <p>seitdem unser Projekt angefangen hat, haben wir beschlossen, etwas gutes für die Natur zu machen, 
                    in dem wir für eine Bestellung für 20 Euro ein Baum pflanzen lassen. 
                </p>
            </div>
            <div class="card">
                <h2>TITLE HEADING</h2>
                <h5>Title description, Feb 1, 2021</h5>
                <img src=<?= IMAGEPATH.'decoration_pics/blog-2.jpeg' ?> alt="blog">

                <p>Some text..</p>
                <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
            </div>
        </div>
