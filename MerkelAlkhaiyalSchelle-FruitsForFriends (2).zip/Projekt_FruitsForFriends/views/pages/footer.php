<!-- bearbeitet von: Anna-Lisa Merkel -->

<div class="footer">
    <footer>
        © 2020-2021 <a href="index.php?c=pages&a=imprint">Impressum</a> Fruits for Friends
        <br>
        <p>Über dieses Formular Kontakt zu uns aufnehmen: <a href="index.php?c=pages&a=support">Kontaktformular</a></p>
        <a href="README.md">README</a>
    </footer>
</div>