<!-- bearbeitet von: Salma Alkhaiyal -->

<div class= "impressum">   
    <h1>Impressum</h1>
        <p> -Fruits for Friends Deutschland GmbH- <br />
            <br />

            <a href="documentation/documentation.html">Link zur Dokumentation</a><br /><br />

            Leipziger Straße 100<br />
            99085 Erfurt<br />
            Deutschland
        </p>
        <p>
            <strong>Kontakt:</strong><br>
            Telefon: 0361 234 687<br />
            E-Mail: <a href="mailto:hallo@fruitsforfriends.de">hallo@fruitsforfriends.de</a><br />
        </p>
        <p>
            <strong>Vertretungsberechtigter Geschäftsführer:</strong><br />
            Anna-Lisa Merkel<br /> 
            Sarah Schelle<br />
            Salma Alkhaiyal
        </p>
        <p> 
            <strong>Umsatzsteuer-ID Nr: </strong>DE128479864<br /> 
            <strong>Steuer Nr: </strong>143/150/6756
        </p>
        <p> 
        <strong>Haftungshinweis: </strong><br />
            Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links.
            Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.
        </p>
</div>