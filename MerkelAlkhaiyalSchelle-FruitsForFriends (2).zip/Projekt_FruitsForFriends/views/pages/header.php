<!-- bearbeitet von: Anna-Lisa Merkel -->

<header>
        <nav class="top-nav">
            <input type="checkbox" id="mobile-nav">
            <label for="mobile-nav">
                <b id="label">Menu</b>
            </label>
            <a href="index.php?c=pages&a=startpage"><img src=<?= IMAGEPATH.'logo.jpg' ?> alt="Logo"></a>
            <ul>
                <li><a href="index.php?c=pages&a=startpage" id="nav1">Startseite</a></li>
                <li><a href="index.php?c=shop&a=products" id="nav2">Unsere Produkte</a></li>
                <li><a href="index.php?c=pages&a=smoothiemaker" id="nav3">Smoothie Maker</a></li>
                <li><a href="index.php?c=pages&a=blog" id="nav4">Blog</a></li>
                <li><a href="index.php?c=pages&a=aboutus" id="nav5">Das sind wir</a></li>
                <li><a href="index.php?c=shop&a=cart">Warenkorb</a></li>
                <li><a href="index.php?c=pages&a=login">Konto</a></li>
            </ul>
        </nav>
</header>